// const API = 'https://raw.githubusercontent.com/Breakhead2/JS2_Advanced/main'; // папка из репозитория

const app = new Vue({
    el: '#app',
    data() {
        return {
            showError: false,
        }
    },
    methods: {
        getJson(url) {
            return fetch(url) // вызываю метод фетч для обращения к внешнему файлу или серверу, фетч вохвращает Promise, значит следом должен идти then
                .then(result => result.json()) // преобразуем json файл с сервера в объект js
                .catch(error => { // если json файл не найден выведем в консоль ошибку
                    console.log(error);
                    this.showError = true;
                })
        },
    }
})